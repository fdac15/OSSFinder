## Project Moved

The project moved to https://github.com/hal/core
