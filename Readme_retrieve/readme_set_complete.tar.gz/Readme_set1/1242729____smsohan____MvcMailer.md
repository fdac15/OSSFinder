MvcMailer is an ASP.NET MVC Mailer, inspired by Ruby on Rails ActionMailer, that helps composing Email
body using regular ASP.NET MVC views. This one works with .Net 4.0 for now.


##How to Use

See [MvcMailer Wiki](https://github.com/smsohan/MvcMailer/wiki/MvcMailer-Step-by-Step-Guide)

##Report Feature or Issues

Use [Github Issues Page](https://github.com/smsohan/mvcmailer/issues) to mention your desired feature or if something is broken!

##Have Fun

I have a lot of fun working on this project. Wish you enjoy using it and if you wish, you can contribute too. Find me on Twitter [@smsohan](http://twitter.com/smsohan)

## Other Contributors
[@TylerMercier](https://github.com/tylermercier)