jQuery News Ticker
-----------------------------------
	 	
An easy to use, slick and flexible news ticker in the style of the BBC News page ticker (http://news.bbc.co.uk).
	 	
Recommended for jQuery 1.4.x or above only (A very early version with support for with jQuery 1.3.2 is available from the website, but is missing some features and is no longer supported).	 	

Please visit http://www.jquerynewsticker.com/ for full documentation and downloads.
	 	
-----------------------------------
 	
Released under GPL v2 - read more here: http://www.gnu.org/licenses/gpl-2.0.html
	 	
Copyright 2011 Rhodri George
