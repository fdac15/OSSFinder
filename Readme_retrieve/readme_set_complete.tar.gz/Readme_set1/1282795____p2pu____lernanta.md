=========
Lernanta
=========

Lernanta is the software that supports P2PU's site, which started as a fork of Mozilla drumbeat's Batucada project. 


Get Involved
------------

To help out with Lernanta, join the `P2PU dev mailing list`_ and introduce yourself. We're currently looking for help from Django / Python and front-end (HTML, CSS, Javascript) developers. 

.. _P2PU dev mailing list: http://lists.p2pu.org/mailman/listinfo/p2pu-dev

Interested in getting involved in Lernanta code development? Check out `the development wiki`_ for more info!

.. _the development wiki: https://github.com/p2pu/lernanta/wiki 

Setup the lernanta development environment quickly with our `environment setup script`_
Or if you enjoy linux command line hacking, check out our `install docs`_ on our wiki. 

.. _environment setup script: https://github.com/p2pu/lernanta-dev-env

.. _install docs: https://github.com/p2pu/lernanta/wiki/Lernanta%27s-Setup-Install