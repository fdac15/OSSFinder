Jenkins Mercurial Plugin
=========================

This plugin integrates the Mercurial version control system with Jenkins.

See [Mercurial Plugin](https://wiki.jenkins-ci.org/display/JENKINS/Mercurial+Plugin) on the Jenkins Wiki for more information.
