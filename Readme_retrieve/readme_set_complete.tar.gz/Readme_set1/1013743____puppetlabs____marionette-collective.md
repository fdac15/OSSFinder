The Marionette Collective
=========================

The Marionette Collective aka. mcollective is a framework to build server orchestration or parallel job execution systems.

For full information, wikis, ticketing and downloads please see https://puppetlabs.com/mcollective
