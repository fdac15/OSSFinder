Quickly install with:

    git clone git://github.com/msanders/snipmate.vim.git
	cd snipmate.vim
	cp -R * ~/.vim
