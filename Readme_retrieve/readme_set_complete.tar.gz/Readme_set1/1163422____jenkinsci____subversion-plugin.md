Jenkins Subversion Plugin
=========================

[![Build Status](https://jenkins.ci.cloudbees.com/buildStatus/icon?job=plugins/subversion-plugin)](https://jenkins.ci.cloudbees.com/job/plugins/job/subversion-plugin/)

Provides Jenkins integration with [Apache Subversion](http://subversion.apache.org/).

See [Subversion Plugin](https://wiki.jenkins-ci.org/display/JENKINS/Subversion+Plugin) on the Jenkins Wiki for more information.

Apache, Apache Subversion and Subversion are trademarks of the Apache Software Foundation.
