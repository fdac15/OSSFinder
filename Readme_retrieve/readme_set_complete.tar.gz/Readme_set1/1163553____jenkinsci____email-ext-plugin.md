Please see https://wiki.jenkins-ci.org/display/JENKINS/Email-ext+plugin for information about the email-ext plugin.
