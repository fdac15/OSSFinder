dmd
===

dmd is the reference compiler for the D programming language.

To report a problem or browse the list of open bugs, please visit the
[bug tracker](http://issues.dlang.org/).

For more information, including instructions for compiling, installing, and
hacking on DMD, visit the [D Wiki](http://wiki.dlang.org/DMD).
