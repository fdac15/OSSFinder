## RailwayJS - MVC framework for NodeJS

Project moved to another repository: [CompoundJS](https://github.com/1602/compound), sorry for inconvenience.

Components for CompoundJS located in separate organization: https://github.com/compoundjs/
