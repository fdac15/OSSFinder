SonataMediaBundle - Media management on steroids
================================================

[![Build Status](https://secure.travis-ci.org/sonata-project/SonataMediaBundle.png)](https://secure.travis-ci.org/#!/sonata-project/SonataMediaBundle)

The ``SonataMediaBundle`` is a media library based on a dedicated ``provider`` which handles different ``type`` of media: files, videos or images.

Check out the documentation on [https://sonata-project.org/bundles/media/master/doc/index.html](https://sonata-project.org/bundles/media/master/doc/index.html)

**Google Groups**: For questions and proposals you can post on this google groups

* [Sonata Users](https://groups.google.com/group/sonata-users): Only for user questions
* [Sonata Devs](https://groups.google.com/group/sonata-devs): Only for devs