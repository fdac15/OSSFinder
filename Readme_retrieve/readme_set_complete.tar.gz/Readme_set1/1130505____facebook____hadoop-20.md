Archived Repo

This is an archived project and is no longer supported or updated by Facebook. Please do not file issues or pull-requests against this repo. If you wish to continue to develop this code yourself, we recommend you fork it.

Proceed and be bold!

---------------------------------

This is a version of code that runs on Facebook's clusters and is powered by
Apache Hadoop. It is used for both the warehouse workloads and the realtime
HBase/Scribe workloads.

This code is based on Apache Hadoop 0.20/Apache Hadoop 0.20-append.

FB-CHANGES.txt contains the additional pathches that have been committed to
the original code base.

For instructions on starting a Corona cluster, see
https://github.com/facebook/hadoop-20/wiki/Corona-Single-Node-Setup.

PLEASE NOTE:

 * This distribution includes cryptographic software that
   is subject to U.S. export control laws and applicable
   export and import laws of other countries. BEFORE using
   any software made available from this site, it is your
   responsibility to understand and comply with these laws.
   This software is being exported in accordance with the
   Export Administration Regulations. As of June 2009, you
   are prohibited from exporting and re-exporting this
   software to Cuba, Iran, North Korea, Sudan, Syria and
   any other countries specified by regulatory update to
   the U.S. export control laws and regulations. Diversion
   contrary to U.S. law is prohibited.
