Gargoyle
--------

.. image:: https://secure.travis-ci.org/disqus/gargoyle.png?branch=master
   :target: http://travis-ci.org/disqus/gargoyle

Gargoyle is a platform built on top of Django which allows you to switch functionality of your application on and off based on conditions.

Resources
---------

* `Documentation <http://gargoyle.readthedocs.org/>`_
* `Bug Tracker <http://github.com/disqus/gargoyle/issues>`_
* `Code <http://github.com/disqus/gargoyle>`_
