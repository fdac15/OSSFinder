# CIlib - Computational Intelligence Library (http://www.cilib.net)

[![Build Status](https://travis-ci.org/cirg-up/cilib.svg?branch=series%2F2.0.x)](https://travis-ci.org/cirg-up/cilib)
[![Join the chat at https://gitter.im/cirg-up/cilib](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/cirg-up/cilib?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

CIlib is a library of various computational intelligence
algorithms. The goal of the project is to create a library that can be used
and referenced by individuals and researchers alike.

