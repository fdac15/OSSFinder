![D Logo](http://dlang.org/images/dlogo.svg) D Language Website
===============================================================

This repository contains the source files for the [D Language
Website](http://dlang.org), including the language specifications,
documentation, and some articles.

* [Bugzilla bug tracker](https://issues.dlang.org/)
* [Forum](http://forum.dlang.org/)
* [Wiki](http://wiki.dlang.org/)

If you wish to contribute to the website or language documentation, please see
the [CONTRIBUTING.md file] (CONTRIBUTING.md).
