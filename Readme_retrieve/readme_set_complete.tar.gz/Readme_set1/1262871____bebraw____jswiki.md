Please see [the wiki](https://github.com/bebraw/jswiki/wiki). :)

## Building

Make sure you have [ghw](https://github.com/bebraw/ghw) installed!

1. Clone wiki (git clone git@github.com:bebraw/jswiki.wiki.git). This will create "jswiki.wiki" directory here.
2. Clone gh-pages (git clone git@github.com:bebraw/jswiki.git, cd jswiki, git checkout -b gh-pages origin/gh-pages). After this you should have "jswiki" directory containing gh-pages branch.
3. Run build.sh. Once that has been done, you should have a fresh build at "jswiki" directory. Commit and push to see it online. You can preview it offline before commit if you want.

