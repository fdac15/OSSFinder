FreeSWITCH
==========

The FreeSWITCH code is no longer hosted in github.
Please visit http://www.freeswitch.org for more info.

