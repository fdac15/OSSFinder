Discontinued - see https://github.com/FriendsOfSymfony/FOSMessageBundle
