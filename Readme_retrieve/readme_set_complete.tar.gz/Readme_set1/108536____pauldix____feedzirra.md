# Feedjira [![Build Status][travis-badge]][travis] [![Code Climate][code-climate-badge]][code-climate]

[travis-badge]: https://travis-ci.org/feedjira/feedjira.png
[travis]: http://travis-ci.org/feedjira/feedjira
[code-climate-badge]: https://codeclimate.com/github/feedjira/feedjira.png
[code-climate]: https://codeclimate.com/github/feedjira/feedjira

Feedjira (formerly Feedzirra) is a Ruby library designed to fetch and parse
feeds as quickly as possible. Version 1.0 was recently released and with it an
[awesome new website][f].

[f]: http://feedjira.com

There you'll find documentation, examples, announcements and more.
