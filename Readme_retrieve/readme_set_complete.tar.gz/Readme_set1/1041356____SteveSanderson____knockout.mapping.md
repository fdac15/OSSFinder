Object mapping plugin for [Knockout](http://knockoutjs.com/) - Find the documentation [here](http://knockoutjs.com/documentation/plugins-mapping.html).
READ THIS
---
Due to lack of time this project is currently not actively maintained. Feel free to be a hero-- step up and [fork this repo](https://github.com/SteveSanderson/knockout.mapping/fork)!
