Use [sugardough][] instead!
===========================

_playdoh_ is Mozilla's old Django app template, but it has been replaced by [sugardough][], which you should use instead.

The [old documentation][docs] for playdoh is available if you need it.

[django]: http://www.djangoproject.com/
[sugardough]: https://github.com/mozilla/sugardough/
[docs]: http://playdoh.rtfd.org/

License
-------
This software is licensed under the [New BSD License][BSD]. For more
information, read the file ``LICENSE``.

[BSD]: http://creativecommons.org/licenses/BSD/
