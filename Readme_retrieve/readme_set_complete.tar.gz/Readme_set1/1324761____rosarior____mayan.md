IMPORTANT! Development of this project has now moved to (https://github.com/mayan-edms/mayan-edms/), please update your git remotes accordingly and post future issues on this new location, thanks!

Join the Mayan EDMS Google Group for the latest news: https://groups.google.com/forum/#!forum/mayan-edms

