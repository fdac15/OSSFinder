# DEPRECATED REPOSITORY #

CartoDB has now a new version! CartoDB 2.0

This repository is deprecated. It's not longer maintained. Please, find CartoDB 2.0 repository in: 

[https://github.com/CartoDB/cartodb20](https://github.com/CartoDB/cartodb20)
