================================================
Canabalt Source Code Release - December 29, 2010
================================================

LEGAL STUFF
-----------

"Canabalt" is a registered trademark of Semi Secret Software,
LLC. "Canabalt" copyright 2009-2010 Semi Secret Software, LLC. "RUN!",
"Daring Escape", and "Mach Runner" copyright 2009-2010 Danny
Baranowsky.  All trademarks and copyrights reserved.

The code contained within the 'flixel-ios' folder is licensed under
the terms of the MIT license. You should read the entire license
(filename "flixel-ios/GAME_LICENSE.TXT" in this archive), so you understand your rights
and what you can and cannot do with the source code from this release.

All other source code remains copyrighted and licensed by Semi Secret
Software, LLC under the original terms. See the Game license
(filename "GAME_LICENSE.TXT" in this archive) for more
details. With the exception of code contained in the 'flixel-ios'
folder, you cannot redistribute our source code from the original
game. You can use our source code for personal entertainment or
education purposes.

With the exception of "RUN!", "Daring Escape", and "Mach Runner", all
of the Canabalt data files remain copyrighted and licensed by Semi
Secret Software, LLC under the original terms.  "RUN!"
(data/music/run.mp3, data/music/run-title.mp3), "Daring Escape"
(data/music/daringescape.mp3, data/music/daringescape-title.mp3), and
"Mach Runner" (data/music/machrunner.mp3,
data/music/machrunner-title.mp3) remain copyrighted and licensed by
Danny Baranowsky under the original terms.  See the Game license
(filename "GAME_LICENSE.TXT in this archive) for more details. You
cannot redistribute our data or data files from the original game. You
can use our data for personal entertainment or educational
purposes. Game data is contained within the "data" folder in this
archive.

Please note that this is being released without any kind of support
from Semi Secret Software, LLC. We cannot help in getting this running
and we do not guarantee that you will be able to get it to work, nor
do we guarantee that it won't blow up your computer and/or iOS device
if you do try and use it. Use at your own risk.

NOTE: Sound effects do not work in the Simulator, only on the device.
