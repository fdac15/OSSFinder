Bukkit
======

A Minecraft Server API.

Website: [http://bukkit.org](http://bukkit.org)  
Bugs/Suggestions: [http://leaky.bukkit.org](http://leaky.bukkit.org)  
Contributing Guidelines: [CONTRIBUTING.md](https://github.com/Bukkit/Bukkit/blob/master/CONTRIBUTING.md)

Compilation
-----------

We use maven to handle our dependencies.

* Install [Maven 3](http://maven.apache.org/download.html)
* Check out this repo and: `mvn clean install`
