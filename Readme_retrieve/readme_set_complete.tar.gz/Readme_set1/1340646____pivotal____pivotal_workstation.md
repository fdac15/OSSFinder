# Warning

This git repository is deprecated. The pivotal_workstation cookbook is now [part of sprout](https://github.com/pivotal-sprout/sprout). Please submit [new issues](https://github.com/pivotal-sprout/sprout/issues) and [pull requests](https://github.com/pivotal-sprout/sprout/pulls) there.

@hiremaga & @cunnie will ensure existing issues and pull requests are addressed as part of this migration. More information will follow in an official announcement in a few weeks.

You can view the old README [here](DEPRECATED.md).