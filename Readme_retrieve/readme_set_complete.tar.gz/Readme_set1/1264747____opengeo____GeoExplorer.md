# NOTICE

The GeoExplorer application has been folded into the [Suite repository](https://github.com/opengeo/suite).  Please find information on the [Suite Client SDK](http://opengeo.org/technology/sdk/) for detail on developing GeoExplorer-like applications.