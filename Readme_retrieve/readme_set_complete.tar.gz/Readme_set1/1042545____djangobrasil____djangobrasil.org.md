To contribute to Django Brasil Project Site:

    * Check out http://code.google.com/p/djangobrasil/wiki/Contribuindo 
      about getting involved.

To get more info:

    * Join the #django-br channel on irc.freenode.net;

    * Join the django-brasil users mailing list, or read the archives,
      at http://groups.google.com/group/django-brasil.

For detailed instructions to install and configure a working copy, see
http://code.google.com/p/djangobrasil/wiki/InstalacaoConfiguracao.
