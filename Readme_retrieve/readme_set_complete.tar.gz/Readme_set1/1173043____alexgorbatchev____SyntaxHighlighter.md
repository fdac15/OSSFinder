# SyntaxHighlighter [![Gittip](http://img.shields.io/gittip/alexgorbatchev.png)](https://www.gittip.com/alexgorbatchev/)

## The project has moved to [github.com/syntaxhighlighter](https://github.com/syntaxhighlighter)
