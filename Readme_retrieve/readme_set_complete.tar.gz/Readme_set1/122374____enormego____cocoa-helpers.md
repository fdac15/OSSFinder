h1. Cocoa Helpers

Created by enormego

Cocoa Helpers are a collection of objective-c categories we've written for the standard Apple Cocoa/UIKit classes to make them more useful.

h1. Documentation

We're going to build our the wiki part as soon as we get some time, in the mean time, you can check out the header files where most methods are documented in line.

h1. Questions

Feel free to contact info@enormego.com if you need any help with any of these methods or wish to contribute to Cocoa Helpers.

h1. License

Cocoa-Helpers are available under the MIT license:

_Copyright (c) 2009 enormego_

_Permission is hereby granted, free of charge, to any person obtaining a copy_
_of this software and associated documentation files (the "Software"), to deal_
_in the Software without restriction, including without limitation the rights_
_to use, copy, modify, merge, publish, distribute, sublicense, and/or sell_
_copies of the Software, and to permit persons to whom the Software is_
_furnished to do so, subject to the following conditions:_

_The above copyright notice and this permission notice shall be included in_
_all copies or substantial portions of the Software._

_THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR_
_IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,_
_FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE_
_AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER_
_LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,_
_OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN_
_THE SOFTWARE._