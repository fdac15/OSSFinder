THIS REPOSITORY IS DEPRECATED
=============================

This is the former GitHub repository for Opscode's public cookbooks for Chef. Usage of this repository is deprecated in favor of individual cookbook repositories in http://github.com/opscode-cookbooks.
