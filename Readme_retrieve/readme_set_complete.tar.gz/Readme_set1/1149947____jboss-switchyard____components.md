Repository for components which can be used with SwitchYard core.
