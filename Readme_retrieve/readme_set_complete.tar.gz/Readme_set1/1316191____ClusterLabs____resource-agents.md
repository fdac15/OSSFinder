This repository contains resource agents (RAs) compliant
with the Open Cluster Framework (OCF) specification.

These resource agents are used by two cluster resource
management implementations:

- Pacemaker
- rgmanager

More information about OCF resource agents is available
in the OCF Resource Agent Developer's guide, in the
doc/dev-guides subdirectory.
