<a href="http://massivecraft.com/factions">
![Factions Logotype](https://raw.github.com/MassiveCraft/Factions/master/media/logo300.png)<br>
<b>http://massivecraft.com/factions</b></a>
