#Rails Ready

This project is deprecated. There are many better options for installing Ruby and Ruby on Rails nowadays.

If you're looking for a Rails dev env, checkout my new project [https://github.com/joshfng/railsbox](https://github.com/joshfng/railsbox) which provisions a Vagrant Box using Ansible suitable for Rails development.
