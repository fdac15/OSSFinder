garb
====

A Ruby wrapper for the Google Analytics API (no longer maintained by Viget).

The official repository is now located here: https://github.com/Sija/garb
