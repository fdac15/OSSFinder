If you are looking for ```filtrr.js``` it is now deprecated and removed. 

Please use the more awesome ```filtrr2```.
