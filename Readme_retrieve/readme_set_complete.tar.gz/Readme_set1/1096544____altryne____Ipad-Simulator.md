iPad Simulator
---
Working apps:

- Safari
- Google Maps
- EveryTimezone 
- Notes (**new**)

Also works:

- Multi-tasking
- Edit mode for apps - You can drag them around, to and from the dock and remove them
- Search
- Lock the iPad and push the home button to wake up to the lock screen