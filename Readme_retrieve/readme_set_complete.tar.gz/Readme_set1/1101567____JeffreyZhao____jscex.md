Jscex项目已经升级至0.7.0，并正式改名为[Wind.js](https://github.com/JeffreyZhao/wind)。

假如您仍然想查看Jscex 0.6.5的源代码，请访问[Wind.js的v0.6.5分支](https://github.com/JeffreyZhao/wind/tree/v0.6.5)。您暂时也可以从[jscex.info](http://jscex.info/zh-cn/)访问Jscex 0.6.5的文档。