--------------------------------------------------------------------------------
Heimdall (c) 2010-2014 Benjamin Dobell, Glass Echidna
http://www.glassechidna.com.au/products/heimdall/

DISCLAIMER:

    This software attempts to flash your Galaxy S device. The very nature of
    flashing is dangerous. As with all flashing software, Heimdall has the
    potential to damage (brick) your phone if not used carefully. If you're
    concerned, don't use this software. Flashing ROMs onto your phone may also
    void your warranty. Benjamin Dobell and Glass Echidna are not responsible
    for the result of your actions.

--------------------------------------------------------------------------------

For more details about how to compile and install Heimdall please refer to the
appropriate platform specific README:

- Linux:
  Linux/README

- OS X
  OSX/README.txt

- Windows
  Win32/README.txt

