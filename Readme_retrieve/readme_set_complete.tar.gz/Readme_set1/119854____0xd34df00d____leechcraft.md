LeechCraft is a free opensource cross-platform modular live environment.
LeechCraft allows one to browse the web, chat in IM via XMPP, IRC, MSN
and a bunch of other protocols, read RSS/Atom feeds, download files via
BitTorrent, FTP, HTTP and ADC/NMDC, automatically download, play or
stream podcasts (and other media files) and much more.

Plugins are easily added and integrated with each other with no effort.

A more or less up-to-date list of plugins is available here:
http://leechcraft.org/plugins

== Getting LeechCraft ==
Getting precompiled LeechCraft for various OS is documented here:
http://leechcraft.org/download

== Building LeechCraft ==
http://leechcraft.org/development-building-from-source
