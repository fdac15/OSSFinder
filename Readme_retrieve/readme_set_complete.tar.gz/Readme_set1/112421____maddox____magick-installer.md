# Magick Installer!

Magick Installer exists for two reasons:

1. installing ImageMagick is hard
2. MacPorts is the devil, and shouldn't be installed just for installing ImageMagick

## How?

    curl https://raw.github.com/maddox/magick-installer/master/magick-installer.sh | sh

or

Download and run this simple script and watch your ImageMagick support go from 0 to 1 without MacPorts.

## Verified Platforms

* Mac OS X 10.7
* Mac OS X 10.6

## Support

This script WILL get stale. As mirrors die and versions increase, the download commands in this script may not work anymore. If this happens to you, please fork the script and fix it. Let's keep this working forever!

