weinre has moved
================

For more information on weinre, please visit

* [`http://people.apache.org/~pmuellr/weinre/`](http://people.apache.org/~pmuellr/weinre/)
