**django-paypal is maintained at: https://github.com/spookylukey/django-paypal**

This fork is no longer maintained.
