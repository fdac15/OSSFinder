# CSSS
### CSS-based SlideShow System

Warning: Only works in latest Firefox, Opera, Safari or Chrome.
For more information, see the [sample slideshow](http://lea.verou.me/csss/sample-slideshow.html) 