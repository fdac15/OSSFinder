## Thudcydides


Thucydides is a library designed to make writing automated acceptance tests easier, and more fun. It helps structure your automated acceptance tests in order to make them easier to understand and maintain, and provides great reporting capabilties on top of tools like JBehave, Cucumber or JUnit. It also provides tight integration with WebDriver, to make automated web testing easier and more efficient.

*Note: In November 2014 Thucydides was renamed Serenity and now has been migrated to a new Git repository: https://github.com/serenity-bdd*
