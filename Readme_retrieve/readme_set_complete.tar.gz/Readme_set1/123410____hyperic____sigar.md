Visit the SIGAR Wiki for documentation, bugs, support, etc.:
http://sigar.hyperic.com/
