== Single Sign-On using Devise and Omniauth ==

We wanted to solve these problems:

* A single User Manager application (which will authenticate ALL users with different roles)
* Different internal applications which talk to User Manager for authentication
* User should be able to login/sign-up via Social Networks like Twitter and Facebook.
* Single Sign On between all applications.

== The Custom Provider

This custom provider acts as an omniauth client (to connect to Twitter & Facebook) AND also
acts as a omniauth provider (via auth_controller) to authenticate internal applications.

== Usage

Clone this repository and do a bundle install. NOTE: We are using devise master HEAD
because it has the latest omniauth integration code.

    git clone git://github.com/joshsoftware/sso-devise-omniauth-provider.git
    bundle install
    rake db:create
    rake db:migrate

Create your Twitter App and Facebook App. Create the initializer file with the following omniauth configuration:( eg. I use config/initializers/omniauth.rb )
  
    Rails.application.config.middleware.use OmniAuth::Builder do
      provider :twitter, 'twitter-appid', 'twitter-app-secret'
      provider :facebook, 'facebook-appid', 'facebook-app-secret'
    end

That's it! Your on your way:

    rails server

In your browser, go for it:

    http://localhost:3000

== Contributions

Please feel free to enhance this demo.
For any doubts, please send an email to gautam@joshsoftware.com

I am eager to write some rspec for this setup. If you do, please send me a pull request!

== License

This is released under the MIT license.
