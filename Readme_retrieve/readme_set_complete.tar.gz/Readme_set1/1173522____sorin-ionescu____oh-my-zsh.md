Oh My Zsh
=========

The **Sorin** fork of [Oh My Zsh][1], discussed in [#377][2], is now [Prezto][3].

[1]: https://github.com/robbyrussell/oh-my-zsh
[2]: https://github.com/robbyrussell/oh-my-zsh/issues/377
[3]: https://github.com/sorin-ionescu/prezto

