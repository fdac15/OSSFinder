h1. CMGdigital UI Developer test

h3. What is this?

This is a UI Developer hiring competency test designed to gauge skill, code completeness and accuracy, and affinity for standards based development.

h3. What are the rules?

Please read the INSTRUCTIONS.textile file and follow the specifications and requirements therein.

h3. How should I deliver my completed test?

The preferred method is delivery via github. Fork this repository, complete the test, then send a pull request. If you require an alternate delivery method, please contact your hiring manager.

h3. Anything else?

You should commit your progress often and write clear and informative commit messages.
