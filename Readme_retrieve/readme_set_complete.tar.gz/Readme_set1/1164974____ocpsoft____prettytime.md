prettytime
==========

Social Style Date and Time Formatting for Java

Learn more at http://ocpsoft.org/prettytime/
