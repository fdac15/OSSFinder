TinyVM is a virtual machine with the goal of having a small footprint.
Low memory usage, a small amount of code, and a small binary.

Building can be accomplished on UNIX-like systems with make and GCC.

There are no external dependencies, save the C standard library.

Building can be accomplished using "make," or "make rebuild".

To build a debug version, add "DEBUG=yes" after "make". To build a binary with
profiling enabled, add "PROFILE=yes" after "make".

I can be reached at "joseph.kogut(at)gmail.com"
