## Deprecation Notice!

This repository has been merged into the [twitter-text mono-repo](https://github.com/twitter/twitter-text) to simplify development, testing, creating issues, and pull requests. This repo is now inactive; please continue all activity in the mono-repo and move existing issues there.

