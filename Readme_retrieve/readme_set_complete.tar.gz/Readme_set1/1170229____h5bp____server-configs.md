# Server Configs

* **[Apache](https://github.com/h5bp/server-configs-apache)**
* **[Google App Engine (GAE)](https://github.com/h5bp/server-configs-gae)**
* **[Internet Information Services (IIS)](https://github.com/h5bp/server-configs-iis)**
* **[lighttpd](https://github.com/h5bp/server-configs-lighttpd)**
* **[Nginx](https://github.com/h5bp/server-configs-nginx)**
* **[Node.js](https://github.com/h5bp/server-configs-node)**
